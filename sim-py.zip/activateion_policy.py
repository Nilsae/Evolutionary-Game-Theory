


def activate_policy_note(population, co_list, a_list):
    w = (self.strategy == self.decide_next_strategy)
    B = 
    if B=1:
        if i is B+:
            if agent[i+1]= A or agent[i-1] = A:
                add agent i to c3
            else if (agent[i+1] = B- and agent[i+2] = A-) or (agent[i-1] = B- and agent[i-2] = A-):
                add agent i to c3



        else if (agent i = B-) and (agent[i+1] = B- and agent[i+2] = A-) or (agent[i-1] = B- and agent[i-2] = A-):
                add agent i to c3
        else if agent i = A- and(agent i+1 = A- or agent i-1 = A-)
                add agent i to c3
        else:
                if w[i]=0:
                    add i to c1
                else add i to c2

    for i in population:
        if i in c1 return i
        if i in c2:
            if activated_before[i]=0:
                activated_before[i]=1
                return i
        if i in c3:
            return i

def check_last_condition:
    check =0
    for i in population:
        if i in c1 or c2 or c3:
            check=1
    return check
if check =0, it must be at eq for policy and what we have written to be ok